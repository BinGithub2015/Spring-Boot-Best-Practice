package com.bestpractice.com.bestpractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BestpracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BestpracticeApplication.class, args);
	}
}
